GPU Shark 2
Simple GPU Monitoring Utility
Copyright (C) 2022-2024 Geeks3D, All rights reserved.

Homepage: https://www.geeks3d.com/gpushark/
Support forum: https://www.geeks3d.com/forums/index.php/board,4.0.html
Discord server: https://www.geeks3d.com/discord/

**************************************************************
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, 
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES 
OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND 
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT 
HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, 
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING 
FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE 
USE OR OTHER DEALINGS IN THE SOFTWARE.
**************************************************************

GPU Shark 2 is a graphics card (GPU) information utility for Windows
and Linux. It is based on the proto-engine GeeXLab (https://www.geeks3d.com/geexlab/). 

Main features of GPU Shark 2:
- GPU information and monitoring (usage, power, temperature, fan speed, etc.)
- 3D API support: OpenGL and Vulkan
- Data export to a file (in the exports/ folder) or to the clipboard.

GPU Shark is shipped in two versions: 32-bit and 64-bit.
The 64-bit version displays more information (for example: GPU monitoring 
of Intel Arc GPUs, Vulkan extensions).

GPU Shark icon:
https://www.flaticon.com/free-icon/gpu_8900415


=======================================
Version history
=======================================

The complete version history is available here:
https://www.geeks3d.com/gpushark/changelog/
