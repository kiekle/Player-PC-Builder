-- GPU Shark 2.3.0.0 settings file.
--
-- Check for new version (true or false).
check_version = true
-- Theme colors: bluish or default.
theme_colors = "bluish"
-- Horizontal splitting size if more than one GPU.
gpu_h_split_size = "720"
-- Energy computing update interval in seconds.
gpu_energy_compute_interval = 10.0
-- Background image (absolute path). Folder separator must be / and not \.
background_image_filename = ""
-- Background opacity from 0.0 to 1.0: 1.0 if fully opaque, 0.0 is fully transparent.
background_alpha = 0.80
